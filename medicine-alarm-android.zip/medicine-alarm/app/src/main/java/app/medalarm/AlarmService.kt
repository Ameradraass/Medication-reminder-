package app.medalarm
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat

class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var wl: PowerManager.WakeLock? = null
    private var curId = -1
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        when (i?.action) {
            "STOP" -> { stopAll(); return START_NOT_STICKY }
            "SNOOZE" -> {
                if (curId != -1) Scheduler.set(this, curId, System.currentTimeMillis() + 5 * 60_000L, true)
                stopAll(); return START_NOT_STICKY
            }
        }
        release()
        curId = i?.getIntExtra("id", -1) ?: -1
        val name = i?.getStringExtra("name") ?: ""
        val dose = i?.getStringExtra("dose") ?: ""
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alarm", getString(R.string.notif_ch), NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC })
        val ui = Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("name", name).putExtra("dose", dose)
        val fs = PendingIntent.getActivity(this, 2, ui, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        fun act(a: String, c: Int) = PendingIntent.getService(this, c, Intent(this, AlarmService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "alarm")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(getString(R.string.ring_title)).setContentText("$name $dose")
            .setCategory(NotificationCompat.CATEGORY_ALARM).setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true).setFullScreenIntent(fs, true).setContentIntent(fs)
            .addAction(0, getString(R.string.taken), act("STOP", 3))
            .addAction(0, getString(R.string.snooze), act("SNOOZE", 4)).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(1, n)

        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "med:alarm").apply { acquire(60 * 60_000L) }
        // The ALARM stream keeps sounding in silent/vibrate mode; force it to maximum.
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(this@AlarmService, uri); isLooping = true; prepare(); start()
            }
        } catch (e: Exception) {}
        @Suppress("DEPRECATION")
        (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(
            VibrationEffect.createWaveform(longArrayOf(0, 800, 400), 0),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        return START_NOT_STICKY
    }

    private fun release() {
        try { player?.stop(); player?.release() } catch (e: Exception) {}
        player = null
        (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel()
        if (wl?.isHeld == true) wl?.release()
    }
    private fun stopAll() { release(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
    override fun onDestroy() { release(); super.onDestroy() }
}
