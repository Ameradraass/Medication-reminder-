package app.medalarm
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.ZonedDateTime

object Scheduler {
    fun next(d: Dose, from: ZonedDateTime = ZonedDateTime.now()): Long? {
        for (i in 0L..8L) {
            val day = from.toLocalDate().plusDays(i)
            if (d.endDay >= 0 && day.toEpochDay() > d.endDay) return null
            if ((d.days and (1 shl (day.dayOfWeek.value - 1))) == 0) continue
            val z = day.atTime(d.hh, d.mm).atZone(from.zone)
            if (z.isAfter(from)) return z.toInstant().toEpochMilli()
        }
        return null
    }
    private fun pi(c: Context, id: Int, snooze: Boolean) = PendingIntent.getBroadcast(
        c, if (snooze) id + 1_000_000 else id,
        Intent(c, AlarmReceiver::class.java).putExtra("id", id).putExtra("snooze", snooze),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, id: Int, at: Long, snooze: Boolean) {
        val am = c.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        try { am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, id, snooze)) } catch (e: SecurityException) {}
    }
    fun schedule(c: Context, d: Dose) { next(d)?.let { set(c, d.id, it, false) } }
    fun cancel(c: Context, id: Int) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(pi(c, id, false)); am.cancel(pi(c, id, true))
    }
    fun rescheduleAll(c: Context) = Store.all(c).forEach { schedule(c, it) }
}
