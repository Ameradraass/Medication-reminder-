package app.medalarm
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Dose(val id: Int, val name: String, val dose: String, val hh: Int, val mm: Int, val days: Int, val endDay: Long)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("med", 0)
    fun all(c: Context): List<Dose> {
        val a = JSONArray(p(c).getString("d", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Dose(o.getInt("id"), o.getString("n"), o.getString("g"), o.getInt("h"), o.getInt("m"), o.getInt("k"), o.getLong("e"))
        }
    }
    fun save(c: Context, l: List<Dose>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("g", it.dose).put("h", it.hh).put("m", it.mm).put("k", it.days).put("e", it.endDay)) }
        p(c).edit().putString("d", a.toString()).commit()
    }
    fun nextId(c: Context): Int { val n = p(c).getInt("n", 1); p(c).edit().putInt("n", n + 1).commit(); return n }
}
