package app.medalarm
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AlarmActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#FFB400")); setPadding(48, 48, 48, 48)
        }
        fun t(s: String, sz: Float) = TextView(this).apply { text = s; textSize = sz; setTextColor(Color.BLACK); gravity = Gravity.CENTER }
        l.addView(t(getString(R.string.ring_title), 22f))
        l.addView(t(intent.getStringExtra("name") ?: "", 36f))
        l.addView(t(intent.getStringExtra("dose") ?: "", 24f))
        fun send(a: String) { startService(Intent(this, AlarmService::class.java).setAction(a)); finish() }
        l.addView(Button(this).apply { text = getString(R.string.taken); textSize = 24f; setOnClickListener { send("STOP") } })
        l.addView(Button(this).apply { text = getString(R.string.snooze); setOnClickListener { send("SNOOZE") } })
        setContentView(l)
    }
}
