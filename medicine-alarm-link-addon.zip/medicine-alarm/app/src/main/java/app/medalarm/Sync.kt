package app.medalarm
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.ZoneId

/** Keeps the server in sync: schedule, ack/snooze events (queued when offline), heartbeat. */
object Sync {
    private fun tok(c: Context) = Api.prefs(c).getString("ptoken", "") ?: ""
    fun linked(c: Context) = tok(c).isNotEmpty()

    @Synchronized private fun pushNow(c: Context): Boolean {
        val p = Api.prefs(c); val arr = JSONArray()
        Store.all(c).forEach { arr.put(JSONObject().put("id", it.id).put("hh", it.hh).put("mm", it.mm).put("days", it.days)
            .put("end_day", it.endDay).put("label", if (p.getBoolean("names", false)) it.name else "")) }
        val ok = Api.call(c, "PUT", "/v1/schedule", JSONObject().put("doses", arr).put("tz", ZoneId.systemDefault().id), tok(c)) != null
        p.edit().putBoolean("dirty", !ok).apply(); return ok
    }
    fun pushSchedule(c: Context) { if (linked(c)) Thread { pushNow(c) }.start() }

    @Synchronized private fun enqueue(c: Context, id: Int, kind: String) {
        val q = JSONArray(Api.prefs(c).getString("q", "[]"))
        q.put(JSONObject().put("dose_id", id).put("kind", kind).put("ts", System.currentTimeMillis() / 1000.0))
        val keep = JSONArray(); for (i in maxOf(0, q.length() - 200) until q.length()) keep.put(q.get(i))
        Api.prefs(c).edit().putString("q", keep.toString()).apply()
    }
    @Synchronized fun flush(c: Context) {
        val q = JSONArray(Api.prefs(c).getString("q", "[]")); val rest = JSONArray()
        for (i in 0 until q.length()) { val e = q.getJSONObject(i); if (rest.length() > 0 || Api.call(c, "POST", "/v1/event", e, tok(c)) == null) rest.put(e) }
        Api.prefs(c).edit().putString("q", rest.toString()).apply()
    }
    fun event(c: Context, id: Int, kind: String) {
        if (!linked(c) || id < 0) return
        enqueue(c, id, kind); Thread { flush(c) }.start()
    }
    /** Called every 5 minutes from the battery check (blocking; runs on a worker thread). */
    fun heartbeat(c: Context, level: Int, charging: Boolean) {
        if (!linked(c)) return
        Api.call(c, "POST", "/v1/heartbeat", JSONObject().put("battery", level).put("charging", charging), tok(c))
        flush(c)
        if (Api.prefs(c).getBoolean("dirty", false)) pushNow(c)
    }
}
