package app.medalarm
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.widget.*
import org.json.JSONObject
import java.time.ZoneId

object LinkUi {
    private fun lang(a: Activity) = a.resources.configuration.locales[0].language.let { if (it == "ar" || it == "de") it else "en" }
    fun section(a: Activity): LinearLayout {
        val p = Api.prefs(a)
        val l = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 64, 0, 64) }
        fun tv(s: String, sz: Float = 14f, bold: Boolean = false) = TextView(a).apply { text = s; textSize = sz; if (bold) setTypeface(typeface, Typeface.BOLD) }
        fun et(h: String, v: String = "") = EditText(a).apply { hint = h; setText(v) }
        fun bt(s: String, f: () -> Unit) = Button(a).apply { text = s; setOnClickListener { f() } }
        fun toast(r: Int) = Toast.makeText(a, r, Toast.LENGTH_LONG).show()

        // ---- patient side ----
        l.addView(tv(a.getString(R.string.l_title), 20f, true))
        if (!Sync.linked(a)) {
            val server = et(a.getString(R.string.l_server), p.getString("server", "") ?: "")
            val name = et(a.getString(R.string.l_pname), p.getString("pname", "") ?: "")
            l.addView(server); l.addView(name)
            l.addView(bt(a.getString(R.string.l_connect)) {
                val srv = server.text.toString().trim().trimEnd('/'); val n = name.text.toString().trim()
                Thread {
                    val r = Api.call(a, "POST", "/v1/register", JSONObject().put("name", n.ifEmpty { "?" }).put("tz", ZoneId.systemDefault().id).put("lang", lang(a)), null, srv)
                    a.runOnUiThread {
                        if (r != null) { p.edit().putString("server", srv).putString("ptoken", r.getString("token")).putString("pname", n).apply()
                            Sync.pushSchedule(a); BatteryMonitor.schedule(a); a.recreate() } else toast(R.string.l_err) }
                }.start()
            })
        } else {
            l.addView(tv(a.getString(R.string.l_linked), 16f, true))
            l.addView(Switch(a).apply { text = a.getString(R.string.l_names); isChecked = p.getBoolean("names", false)
                setOnCheckedChangeListener { _, c -> p.edit().putBoolean("names", c).apply(); Sync.pushSchedule(a) } })
            val code = tv("", 18f, true)
            l.addView(bt(a.getString(R.string.l_invite)) {
                Thread { val r = Api.call(a, "POST", "/v1/invite", JSONObject(), p.getString("ptoken", ""))
                    a.runOnUiThread { if (r != null) code.text = a.getString(R.string.l_invite_show, r.getString("code")) else toast(R.string.l_err) } }.start() })
            l.addView(code)
        }

        // ---- caregiver side ----
        l.addView(tv(a.getString(R.string.l_cg_title), 20f, true).apply { setPadding(0, 64, 0, 0) })
        if (p.getString("ctoken", "").isNullOrEmpty()) {
            val cs = et(a.getString(R.string.l_server), p.getString("cserver", "") ?: "")
            val code2 = et(a.getString(R.string.l_code))
            l.addView(cs); l.addView(code2)
            l.addView(bt(a.getString(R.string.l_join)) {
                val srv = cs.text.toString().trim().trimEnd('/')
                Thread {
                    val r = Api.call(a, "POST", "/v1/join", JSONObject().put("code", code2.text.toString().trim()).put("lang", lang(a)), null, srv)
                    a.runOnUiThread {
                        if (r != null) { p.edit().putString("cserver", srv).putString("ctoken", r.getString("token")).putString("ctopic", r.getString("topic"))
                            .putString("cntfy", r.getString("ntfy_server")).apply(); a.recreate() } else toast(R.string.l_err) }
                }.start()
            })
        } else {
            val topic = p.getString("ctopic", "") ?: ""
            l.addView(tv(a.getString(R.string.l_joined, topic)))
            l.addView(bt(a.getString(R.string.l_open_ntfy)) {
                try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("ntfy://" + Uri.parse(p.getString("cntfy", "https://ntfy.sh")).host + "/" + topic))) }
                catch (e: Exception) { toast(R.string.l_nontfy) } })
            val status = tv("", 16f)
            l.addView(bt(a.getString(R.string.l_status)) {
                Thread {
                    val r = Api.call(a, "GET", "/v1/caregiver/status", null, p.getString("ctoken", ""), p.getString("cserver", ""))
                    a.runOnUiThread {
                        if (r == null) { toast(R.string.l_err); return@runOnUiThread }
                        val sb = StringBuilder(r.getString("name")).append("\n")
                        val ago = ((r.getDouble("now") - r.getDouble("last_seen")) / 60).toLong().coerceAtLeast(0)
                        sb.append(a.getString(R.string.l_last, BatteryMonitor.fmt(a, ago))).append("\n")
                        if (!r.isNull("battery")) sb.append(a.getString(R.string.l_batt, r.getInt("battery"))).append("\n")
                        val arr = r.getJSONArray("today")
                        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i)
                            sb.append(if (o.getBoolean("acked")) "✓ " else "✗ ").append(String.format("%02d:%02d", o.getInt("hh"), o.getInt("mm"))).append(" ").append(o.optString("label")).append("\n") }
                        status.text = sb.toString() }
                }.start() })
            l.addView(status)
        }
        return l
    }
}
