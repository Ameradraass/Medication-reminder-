package app.medalarm
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("link", 0)
    /** Returns the JSON reply, or null on any failure (network or HTTP error). Servers must use https. */
    fun call(c: Context, method: String, path: String, body: JSONObject?, token: String?, base: String? = null): JSONObject? {
        val b = (base ?: prefs(c).getString("server", "") ?: "").trim().trimEnd('/')
        if (!b.startsWith("https://")) return null
        return try {
            val h = URL(b + path).openConnection() as HttpURLConnection
            h.requestMethod = method; h.connectTimeout = 5000; h.readTimeout = 5000
            if (!token.isNullOrEmpty()) h.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) { h.doOutput = true; h.setRequestProperty("Content-Type", "application/json"); h.outputStream.use { it.write(body.toString().toByteArray()) } }
            val code = h.responseCode
            val txt = (if (code in 200..299) h.inputStream else h.errorStream)?.bufferedReader()?.readText() ?: ""
            h.disconnect()
            if (code in 200..299) JSONObject(if (txt.isBlank()) "{}" else txt) else null
        } catch (e: Exception) { null }
    }
}
