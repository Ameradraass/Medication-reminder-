package app.medalarm
import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle

class P(val label: Int, val ok: Boolean, val ask: () -> Unit)

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private var hh = 8
    private var mm = 0
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(s: CharSequence, sz: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = sz; if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(6), 0, dp(6)) }
    private fun btn(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
    private fun dayName(n: Int) = DayOfWeek.of(n).getDisplayName(TextStyle.SHORT, resources.configuration.locales[0])

    private fun perms(): List<P> {
        val uri = Uri.parse("package:$packageName")
        val l = mutableListOf<P>()
        l += P(R.string.p_notif, Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
        l += P(R.string.p_exact, Build.VERSION.SDK_INT < 31 || getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, uri)) }
        l += P(R.string.p_fsi, Build.VERSION.SDK_INT < 34 || getSystemService(NotificationManager::class.java).canUseFullScreenIntent()) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, uri)) }
        l += P(R.string.p_battery, getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, uri)) }
        return l
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        val sv = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(24)) }
        sv.addView(root); setContentView(sv)
        val langs = LinearLayout(this)
        listOf("ar" to "العربية", "de" to "Deutsch", "en" to "English").forEach { (c, n) ->
            langs.addView(btn(n) { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(c)) }) }
        root.addView(langs)
        val p = perms()
        if (p.any { !it.ok }) gate(p) else main()
    }

    private fun gate(p: List<P>) {
        root.addView(tv(getString(R.string.grant_title), 22f, true))
        root.addView(tv(getString(R.string.grant_intro)))
        p.forEach { root.addView(tv((if (it.ok) "✓  " else "✗  ") + getString(it.label), 18f)) }
        root.addView(btn(getString(R.string.grant_btn)) { p.first { !it.ok }.ask() })
    }

    private fun main() {
        BatteryMonitor.schedule(this)
        root.addView(tv(getString(R.string.add_title), 20f, true))
        val name = EditText(this).apply { hint = getString(R.string.med_name) }
        val dose = EditText(this).apply { hint = getString(R.string.med_dose) }
        val dur = EditText(this).apply { hint = getString(R.string.duration_hint); inputType = InputType.TYPE_CLASS_NUMBER }
        val timeBtn = Button(this)
        fun lbl() = getString(R.string.pick_time, String.format("%02d:%02d", hh, mm))
        timeBtn.text = lbl()
        timeBtn.setOnClickListener { TimePickerDialog(this, { _, h, m -> hh = h; mm = m; timeBtn.text = lbl() }, hh, mm, true).show() }
        val dayRow = LinearLayout(this)
        val boxes = (1..7).map { n -> CheckBox(this).apply { text = dayName(n); isChecked = true }.also { dayRow.addView(it) } }
        listOf(name, dose, timeBtn, dayRow, dur).forEach { root.addView(it) }
        root.addView(btn(getString(R.string.add_btn)) {
            val n = name.text.toString().trim()
            var mask = 0
            boxes.forEachIndexed { i, b -> if (b.isChecked) mask = mask or (1 shl i) }
            if (n.isEmpty() || mask == 0) { Toast.makeText(this, R.string.need_name, Toast.LENGTH_LONG).show(); return@btn }
            val days = dur.text.toString().toLongOrNull()
            val end = if (days != null && days > 0) LocalDate.now().toEpochDay() + days - 1 else -1L
            val d = Dose(Store.nextId(this), n, dose.text.toString().trim(), hh, mm, mask, end)
            Store.save(this, Store.all(this) + d); Scheduler.schedule(this, d); Sync.pushSchedule(this); render()
        })
        root.addView(tv(getString(R.string.schedule), 20f, true))
        val list = Store.all(this).sortedBy { it.hh * 60 + it.mm }
        if (list.isEmpty()) root.addView(tv(getString(R.string.empty)))
        list.forEach { d ->
            val days = (1..7).filter { d.days and (1 shl (it - 1)) != 0 }.joinToString(" ") { dayName(it) }
            val row = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
            row.addView(tv(String.format("%02d:%02d  %s %s\n%s", d.hh, d.mm, d.name, d.dose, days)), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(btn(getString(R.string.delete)) {
                Scheduler.cancel(this, d.id); Store.save(this, Store.all(this).filter { it.id != d.id }); Sync.pushSchedule(this); render() })
            root.addView(row)
        }
        root.addView(btn(getString(R.string.test_btn)) { Scheduler.set(this, -1, System.currentTimeMillis() + 5000, true) })
        root.addView(BatteryUi.section(this))
        root.addView(LinkUi.section(this))
    }
}
