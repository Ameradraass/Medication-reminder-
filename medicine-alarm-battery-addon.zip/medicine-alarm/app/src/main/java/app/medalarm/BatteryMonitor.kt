package app.medalarm
import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.os.BatteryManager
import androidx.core.app.NotificationCompat

/** Checks the battery every 5 minutes (exact alarm, works in Doze) and warns before it runs out. */
object BatteryMonitor {
    private const val EVERY = 5 * 60_000L
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("bat", 0)

    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 77, Intent(c, BatteryCheckReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(c: Context) {
        val p = prefs(c)
        if (!p.getBoolean("on", true)) { c.getSystemService(AlarmManager::class.java).cancel(pi(c)); p.edit().putLong("armed", 0).apply(); return }
        if (p.getLong("armed", 0) > System.currentTimeMillis()) return
        arm(c)
    }
    private fun arm(c: Context) {
        val at = System.currentTimeMillis() + EVERY
        try { c.getSystemService(AlarmManager::class.java).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c)); prefs(c).edit().putLong("armed", at).apply() }
        catch (e: SecurityException) {}
    }
    private fun fmt(c: Context, m: Long): String {
        val h = m / 60; val mi = m % 60
        return when {
            h > 0 && mi > 0 -> c.getString(R.string.b_unit_h, h.toInt()) + " " + c.getString(R.string.b_unit_m, mi.toInt())
            h > 0 -> c.getString(R.string.b_unit_h, h.toInt())
            else -> c.getString(R.string.b_unit_m, maxOf(m, 1L).toInt())
        }
    }

    fun check(c: Context) {
        val p = prefs(c)
        if (!p.getBoolean("on", true)) return
        arm(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0) {   // charging: reset everything
            p.edit().putInt("stage", 0).putLong("t0", 0).remove("pend").apply(); nm.cancel(77); return }
        val now = System.currentTimeMillis()
        var t0 = p.getLong("t0", 0); var l0 = p.getInt("l0", lvl)
        if (t0 == 0L || lvl > l0) { t0 = now; l0 = lvl; p.edit().putLong("t0", t0).putInt("l0", l0).apply() }
        val mins = (now - t0) / 60000.0
        val rate = if (mins >= 20 && l0 > lvl) (l0 - lvl) / mins else 0.15      // % per minute (fallback: 9%/hour)
        val left = (lvl / rate).toLong().coerceAtMost(24 * 60L)                    // estimated minutes until empty
        val nd = Store.all(c).mapNotNull { Scheduler.next(it) }.minOrNull()
        val untilDose = nd?.let { ((it - now) / 60000).coerceAtLeast(0) }
        val risk = untilDose != null && left < untilDose + 30                       // may die before (or just after) the next dose

        p.getString("pend", null)?.let { if (Notifier.sendBlocking(c, it, p.getInt("pendp", 4))) p.edit().remove("pend").apply() }

        var stage = 0
        if (left <= 60) stage = 1; if (left <= 30) stage = 2; if (left <= 10) stage = 3
        if (lvl <= 15) stage = maxOf(stage, 1); if (lvl <= 8) stage = maxOf(stage, 2); if (lvl <= 5) stage = 3
        if (stage == 0 || !(risk || lvl <= 15) || stage <= p.getInt("stage", 0)) return
        p.edit().putInt("stage", stage).apply()

        val leftTxt = fmt(c, left)
        val doseTxt = untilDose?.let { fmt(c, it) }
        val localText = if (doseTxt != null) c.getString(R.string.b_local, lvl, leftTxt, doseTxt) else c.getString(R.string.b_local_nodose, lvl, leftTxt)
        localAlert(c, nm, localText)

        val who = p.getString("name", "")?.takeIf { it.isNotBlank() } ?: c.getString(R.string.app_name)
        val remote = if (doseTxt != null) c.getString(R.string.b_remote, who, lvl, leftTxt, doseTxt) else c.getString(R.string.b_remote_nodose, who, lvl, leftTxt)
        val prio = if (stage >= 2) 5 else 4
        if (!Notifier.sendBlocking(c, remote, prio)) p.edit().putString("pend", remote).putInt("pendp", prio).apply()
    }

    private fun localAlert(c: Context, nm: NotificationManager, text: String) {
        try { val am = c.getSystemService(AudioManager::class.java); am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0) } catch (e: Exception) {}
        val ch = NotificationChannel("battery", c.getString(R.string.b_channel), NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            enableVibration(true); vibrationPattern = longArrayOf(0, 700, 300, 700); lockscreenVisibility = Notification.VISIBILITY_PUBLIC }
        nm.createNotificationChannel(ch)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, "battery").setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setContentTitle(c.getString(R.string.b_notif_title)).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_ALARM).setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true).setContentIntent(open).build()
        n.flags = n.flags or Notification.FLAG_INSISTENT     // repeat the sound until tapped
        nm.notify(77, n)
    }
}

class BatteryCheckReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val pr = goAsync(); val app = c.applicationContext
        Thread { try { BatteryMonitor.check(app) } catch (e: Exception) {} finally { pr.finish() } }.start()
    }
}
