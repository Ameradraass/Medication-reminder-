package app.medalarm
import android.app.Activity
import android.graphics.Typeface
import android.widget.*
import java.security.SecureRandom

object BatteryUi {
    fun section(a: Activity): LinearLayout {
        val p = BatteryMonitor.prefs(a)
        val l = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 64, 0, 0) }
        fun tv(s: String, sz: Float, bold: Boolean = false) = TextView(a).apply { text = s; textSize = sz; if (bold) setTypeface(typeface, Typeface.BOLD) }
        val sw = Switch(a).apply { text = a.getString(R.string.b_enable); isChecked = p.getBoolean("on", true) }
        val topic = EditText(a).apply { hint = a.getString(R.string.b_topic_hint); setText(p.getString("topic", "")) }
        val name = EditText(a).apply { hint = a.getString(R.string.b_name_hint); setText(p.getString("name", "")) }
        val gen = Button(a).apply { text = a.getString(R.string.b_gen); setOnClickListener {
            val r = SecureRandom(); val abc = "abcdefghijklmnopqrstuvwxyz0123456789"
            topic.setText("ma-" + (1..20).map { abc[r.nextInt(abc.length)] }.joinToString("")) } }
        fun save(): Boolean {
            val t = topic.text.toString().trim()
            if (sw.isChecked && t.isNotEmpty() && !Regex("[A-Za-z0-9_-]{12,64}").matches(t)) { Toast.makeText(a, R.string.b_topic_bad, Toast.LENGTH_LONG).show(); return false }
            p.edit().putBoolean("on", sw.isChecked).putString("topic", t).putString("name", name.text.toString().trim()).apply()
            BatteryMonitor.schedule(a); return true
        }
        val saveBtn = Button(a).apply { text = a.getString(R.string.b_save); setOnClickListener { if (save()) Toast.makeText(a, R.string.b_saved, Toast.LENGTH_SHORT).show() } }
        val testBtn = Button(a).apply { text = a.getString(R.string.b_test); setOnClickListener {
            if (!save()) return@setOnClickListener
            if (topic.text.isBlank()) { Toast.makeText(a, R.string.b_topic_bad, Toast.LENGTH_LONG).show(); return@setOnClickListener }
            val who = name.text.toString().trim().ifEmpty { a.getString(R.string.app_name) }
            Notifier.sendAsync(a, a.getString(R.string.b_test_msg, who), 3) { ok -> Toast.makeText(a, if (ok) R.string.b_test_ok else R.string.b_test_fail, Toast.LENGTH_LONG).show() } } }
        listOf(tv(a.getString(R.string.b_title), 20f, true), sw, topic, gen, name, saveBtn, testBtn, tv(a.getString(R.string.b_help), 14f)).forEach { l.addView(it) }
        return l
    }
}
