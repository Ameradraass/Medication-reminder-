package app.medalarm
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val d = if (id == -1) Dose(-1, "Test", "", 0, 0, 0, -1) else Store.all(c).find { it.id == id } ?: return
        if (!i.getBooleanExtra("snooze", false) && id != -1) Scheduler.schedule(c, d)
        ContextCompat.startForegroundService(c, Intent(c, AlarmService::class.java)
            .putExtra("id", id).putExtra("name", d.name).putExtra("dose", d.dose))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.rescheduleAll(c); BatteryMonitor.schedule(c) }
}
