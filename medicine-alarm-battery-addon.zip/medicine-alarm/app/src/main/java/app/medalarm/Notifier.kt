package app.medalarm
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL

/** Sends a push to the caregiver through ntfy (https://ntfy.sh). Change SERVER to use your own ntfy server. */
object Notifier {
    const val SERVER = "https://ntfy.sh"
    fun sendBlocking(c: Context, text: String, prio: Int): Boolean {
        val t = BatteryMonitor.prefs(c).getString("topic", "")?.trim().orEmpty()
        if (t.isEmpty()) return true
        return try {
            val h = URL("$SERVER/$t").openConnection() as HttpURLConnection
            h.requestMethod = "POST"; h.doOutput = true; h.connectTimeout = 10000; h.readTimeout = 10000
            h.setRequestProperty("Priority", prio.toString()); h.setRequestProperty("Title", "Medicine Alarm"); h.setRequestProperty("Tags", "battery,warning")
            h.outputStream.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            val ok = h.responseCode in 200..299; h.disconnect(); ok
        } catch (e: Exception) { false }
    }
    fun sendAsync(c: Context, text: String, prio: Int, done: (Boolean) -> Unit) {
        Thread { val ok = sendBlocking(c, text, prio); Handler(Looper.getMainLooper()).post { done(ok) } }.start()
    }
}
